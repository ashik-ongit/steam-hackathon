import csv
from pymongo import MongoClient

# MongoDB connection string
uri = "mongodb+srv://kashikashik09:Zx8Jt1laKOpLkIqw@cluster0.glqdtqo.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)

# Use database and collection
db = client["steamdata"]
collection = db["games"]

# Read CSV and upload
with open("steam.csv", newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    data = list(reader)
    collection.insert_many(data)

print("✅ Data uploaded successfully bruh!")
