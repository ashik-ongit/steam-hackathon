import streamlit as st
import pymongo
import base64

# MongoDB connection
client = pymongo.MongoClient("mongodb+srv://kashikashik09:Zx8Jt1laKOpLkIqw@cluster0.glqdtqo.mongodb.net/?retryWrites=true&w=majority")
db = client["steam"]
collection = db["games"]

# Page setup
st.set_page_config(page_title="🎮 Steam Game Explorer", layout="wide")

# Load and encode GIF for background
def get_base64_gif(file_path):
    with open(file_path, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

gif_data = get_base64_gif("giff.gif")  # Make sure this file exists

# Custom CSS styling
st.markdown(f"""
    <style>
    .stApp {{
        background-image: url("data:image/gif;base64,{gif_data}");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        color: white;
        font-family: 'Segoe UI', sans-serif;
    }}
    h1 {{
        font-size: 1.8rem !important;
        color: #00ffe1;
    }}
    .subtitle {{
        font-size: 0.9rem;
        color: #aaa;
        margin-bottom: 1.2rem;
    }}
    .game-card {{
        background-color: rgba(26, 26, 26, 0.85);
        padding: 1rem;
        border-radius: 16px;
        box-shadow: 0 0 10px #00ffe1;
        margin-bottom: 1rem;
    }}
    .title {{
        font-size: 1.3rem;
        font-weight: bold;
        color: #00ffe1;
    }}
    .tag {{
        font-size: 0.9rem;
        background-color: #ff4081;
        color: white;
        padding: 0.2rem 0.6rem;
        border-radius: 8px;
        margin-right: 0.5rem;
    }}
    .description {{
        font-size: 0.85rem;
        margin-top: 0.6rem;
        color: #eee;
    }}
    .game-image {{
        max-width: 100%;
        height: auto;
        border-radius: 12px;
        margin-top: 10px;
        box-shadow: 0 0 10px #00ffe1;
    }}
    </style>
""", unsafe_allow_html=True)

# Title and subtitle
st.markdown("<h1>🎮 Steam Game Explorer</h1>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Search your favorite games like GTA, COD, or NFS</div>", unsafe_allow_html=True)

# Search box
search = st.text_input("Type a game name to search", "").lower()

# Show results
if search:
    results = collection.find({"name": {"$regex": search, "$options": "i"}}).limit(20)
    for game in results:
        st.markdown(f"""
            <div class="game-card">
                <div class="title">{game.get('name', 'Unknown Game')}</div>
                <div>
                    <span class="tag">🎯 Genre: {game.get('genre', 'Unknown')}</span>
                    <span class="tag">💸 Price: {game.get('price', 'Free')}</span>
                </div>
                <div class="description">{game.get('description', 'No description available.')}</div>
        """, unsafe_allow_html=True)

        # Game image
        image_url = game.get("image_url")
        if image_url:
            st.markdown(f"""<img class="game-image" src="{image_url}" />""", unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

# Neon Footer
st.markdown("""
<div style='
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.6);
    padding: 10px 20px;
    border-radius: 12px;
    font-size: 0.9rem;
    color: #00ffe1;
    font-weight: bold;
    text-shadow: 0 0 5px #00ffe1, 0 0 10px #00ffe1, 0 0 20px #00ffe1;
    box-shadow: 0 0 10px #00ffe1;
'>
🚀 Built by Ashik K
</div>
""", unsafe_allow_html=True)
